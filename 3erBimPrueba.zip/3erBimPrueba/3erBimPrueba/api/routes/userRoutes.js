const {Router} = require('express')
const router = Router()
const {getUsers,
    usersById,
    registerUser,
    login,
    me} = require('../controllers/userController.js')
const {isAuth} = require('../middlewares/auth.js')

    router.get('/',isAuth,getUsers)
    router.get('/users/:id',isAuth,usersById)
    router.post('/register',registerUser)
    router.post('/login',login)
    router.get('/me',isAuth,me)

    module.exports = router