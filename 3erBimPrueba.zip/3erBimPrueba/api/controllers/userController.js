const User = require ('../models/userModel.js')
const bcrypt = require ('bcrypt')
const jwt = require('jsonwebtoken')
const { use } = require('react')
const { where } = require('sequelize')

const SECRET = 'EsUnSecretoooooooDeTuMiradaYLaMíaUnPresentimientoComoUnAngelQueMeDecía'

const getUsers = async(req,res) =>{
    const users = await User.findAll({attributes : {exlude: 'contraseña'}})
    res.json(users)
}
const usersById = async (req,res)=>{
    const user = await User.findByPk(req.params.id,{
        attributes : { exlude :'constraseña',
        }
    })
    res.json(user)
}

const registerUser = async (req,res)   =>{
    const {nombre,apellido,gmail,contraseña} = req.body
    const contraseñaHasheada = await bcrypt.hash(contraseña,10)
    const user = await User.create({
        nombre,
        apellido,
        gmail,
        contraseña : contraseñaHasheada
    })
    res.json (user)
}
const login = async (req,res)=>{
    const {gmail,contraseña} = req.body
    const user = await User.findOne({
        gmail
    })
    if (!user) return res.status(400).json({ message: 'Usuario no encontrado' })
        const compare = await bcrypt.compare(contraseña, user.contraseña);
        if (!compare) return res.status(400).json({ message: 'Usuario o contraseña incorrecta' })

            const token = jwt.sign({id : user.id, gmail: user.gmail}, SECRET, {expiresIn: '8h'})

            res.json({token})
}
const me = async (req,res)=>{
    const user = await User.findByPk(req.users.id,
       {attributes: {exlude: 'contraseña'}})
       res.json(user)
}

module.exports ={
    getUsers,
    usersById,
    registerUser,
    login,
    me
}