const express = require('express')
const {getUsers,
    usersById,
    registerUser,
    login,
    me} = require('../controllers/userController.js')
const {isAuth} = require('../middlewares/auth.js')

    server.get('/',getUsers)
    server.get('/users/:id')