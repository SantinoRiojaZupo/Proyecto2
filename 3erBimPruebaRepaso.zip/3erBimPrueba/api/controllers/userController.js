const User = require ('../models/userModel.js')
const bcrypt = require ('bcrypt')
const jwt = require('jsonwebtoken')
const { where } = require('sequelize')

const SECRET = 'EsUnSecretoooooooDeTuMiradaYLaMíaUnPresentimientoComoUnAngelQueMeDecía'

const getUsers = async(req,res) =>{
    const users = await User.findAll({attributes : {exclude: 'contraseña'}})
    res.json(users)
}
const usersById = async (req,res)=>{
    try {
        const id= req.params.id
        const user = await User.findByPk(id,{
            attributes : { exclude :'contraseña',
            }
        })
        res.json(user)
            
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error al buscar el usuario", error });
    }
}

const registerUser = async (req,res)   =>{
    const {nombre,apellido,gmail,contraseña} = req.body
    const contraseñaHasheada = await bcrypt.hash(contraseña,10)
    const user = await User.create({
        nombre,
        apellido,
        gmail,
        contraseña : contraseñaHasheada
    })
    res.json (user)
}
const login = async (req,res)=>{
    const {gmail,contraseña} = req.body
    const user = await User.findOne({
        where:{
        gmail}
    })
    if (!user) return res.status(400).json({ message: 'Usuario no encontrado' })
        const compare = await bcrypt.compare(contraseña, user.contraseña);
        if (!compare) return res.status(400).json({ message: 'Usuario o contraseña incorrecta' })

            const token = jwt.sign({id : user.id, gmail: user.gmail}, SECRET, {expiresIn: '8h'})

            res.json({token})
}
const me = async (req,res)=>{
    const user = await User.findByPk(req.user.id,
       {attributes: {exclude: 'contraseña'}})
       res.json(user)
}

module.exports ={
    getUsers,
    usersById,
    registerUser,
    login,
    me
}