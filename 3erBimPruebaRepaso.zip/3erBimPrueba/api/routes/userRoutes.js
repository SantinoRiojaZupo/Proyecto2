const {Router} = require('express')
const router = Router()
const {getUsers,
    usersById,
    registerUser,
    login,
    me} = require('../controllers/userController.js')
const {isAuth} = require('../middlewares/auth.js')

    router.get('/',isAuth,getUsers)
    router.get('/me',isAuth,me)
    router.post('/register',registerUser)
    router.post('/login',login)
    router.get('/:id',isAuth,usersById)

    module.exports = router