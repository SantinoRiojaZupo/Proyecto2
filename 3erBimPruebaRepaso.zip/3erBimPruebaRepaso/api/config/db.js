const Sequelize = require ('sequelize')

const sequelize = new Sequelize('repaso_3erbim','postgres','1234',{
    host : 'localhost',
    dialect : 'postgres',
    logging : false
}) ;

    module.exports = sequelize