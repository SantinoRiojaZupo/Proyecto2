const User = require('../models/userModel.js')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const { where } = require('sequelize')

const SECRET = 'EsUnSecretoooooooDeTuMiradaYLaMíaUnPresentimientoComoUnAngelQueMeDecía'

const getUsers = async (req, res) => {
    const users = await User.findAll({ attributes: { exclude: 'contraseña' } })
    res.json(users)
}
const usersById = async (req, res) => {
    try {
        const id = req.params.id
        const user = await User.findByPk(id, {
            attributes: {
                exclude: 'contraseña',
            }
        })
        res.json(user)

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error al buscar el usuario", error });
    }
}

const registerUser = async (req, res) => {
    const { nombre, apellido, gmail, contraseña } = req.body
    const contraseñaHasheada = await bcrypt.hash(contraseña, 10)
    const user = await User.create({
        nombre,
        apellido,
        gmail,
        contraseña: contraseñaHasheada
    })
    res.json(user)
}
const login = async (req, res) => {
    const { gmail, contraseña } = req.body
    const user = await User.findOne({
        where: {
            gmail
        }
    })
    if (!user) return res.status(400).json({ message: 'Usuario no encontrado' })
    const compare = await bcrypt.compare(contraseña, user.contraseña);
    if (!compare) return res.status(400).json({ message: 'Usuario o contraseña incorrecta' })

    const token = jwt.sign({ id: user.id, gmail: user.gmail }, SECRET, { expiresIn: '8h' })

    res.json({ token })
}
const me = async (req, res) => {
    const user = await User.findByPk(req.user.id,
        { attributes: { exclude: 'contraseña' } })
    res.json(user)
}
const forgotPassword = async (req, res) => {
    try {
        const { gmail } = req.body;
        
        const user = await User.findOne({ where: { gmail } });
        if (!user) {
            return res.status(404).json({ message: "Usuario no encontrado" });
        }

        const unaHora = new Date();
        unaHora.setHours(unaHora.getHours() + 1);

        // Generamos el token de recuperación con duración de 1 hora
        const tokenRecuperacion = jwt.sign({ id: user.id, gmail: user.gmail }, SECRET, { expiresIn: '1h' });

        // Actualizamos el usuario guardando el token y su expiración en la base de datos
        await User.update({
            resetPasswordToken: tokenRecuperacion,
            resetPasswordExpires: unaHora
        }, {
            where: { gmail: gmail }
        });

        // ¡IMPORTANTE! Solo enviamos UNA respuesta HTTP
        res.json({ 
            message: "Token de recuperación generado con éxito",
            tokenRecuperacion : tokenRecuperacion
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error en el servidor", error });
    }
}

const cambiarContraseña = async (req, res) => {
    try {
        const { contraseña } = req.body;
        
        // Obtenemos el email directamente de req.user (gracias al middleware de seguridad)
        const gmail = req.user.gmail;

        const contraseñaHasheada = await bcrypt.hash(contraseña, 10);

        // Actualizamos la contraseña y limpiamos los campos de recuperación para que el token no se pueda reutilizar
        await User.update({
            contraseña: contraseñaHasheada,
            resetPasswordToken: null,
            resetPasswordExpires: null
        }, {
            where: { gmail: gmail }
        });

        res.json({ message: "Contraseña actualizada exitosamente" });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error al cambiar la contraseña", error });
    }
}   
const cambiarPerfil = async (req, res) => {
    const { profilePictureUrl } = req.body
    
    userId= req.user.id
    const user = await User.update({
        profilePictureUrl : req.user.profilePictureUrl
    },
{where:{id:userId}}
)
    res.json(user)
}

module.exports = {
    getUsers,
    usersById,
    registerUser,
    login,
    me,
    forgotPassword,
    cambiarContraseña,
    cambiarPerfil
}