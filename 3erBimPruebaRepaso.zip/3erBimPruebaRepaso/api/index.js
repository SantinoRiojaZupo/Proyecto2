const express = require ("express")
const sequelize = require ('./config/db.js')
const cors = require ('cors')


const userRoutes= require ('./routes/userRoutes.js')

const server =  express()


server.use(express.json())
server.use(cors())
// Middleware para configurar los headers CORS
/*server.use((req, res, next) => {
  // 👇 Acá decís qué origen tiene permiso
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:5173')
  // 👇 Métodos HTTP permitidos
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
  // 👇 Qué headers puede mandar el frontend
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization')
  // 👇 Si querés permitir cookies/tokens en las peticiones
  res.setHeader('Access-Control-Allow-Credentials', 'true')
  // Si es una petición OPTIONS (preflight), respondemos rápido
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200)
  }
  next()
})
*/

server.use('/user',userRoutes) //Ej: /user/register y /user/login

server.listen(3000,async()=>{
  await sequelize.sync({force:false})
console.log("El servidor esta corriendo en el puerto 3000")
})