const jwt = require ('jsonwebtoken')
const User = require('../models/userModel.js')

const SECRET = 'EsUnSecretoooooooDeTuMiradaYLaMíaUnPresentimientoComoUnAngelQueMeDecía'

const isAuth = (req,res,next) =>{
    const token = req.headers['authorization'].split(" ")[1] || req.headers['authorization']
    console.log(token)

    try {
        jwt.verify(token,SECRET,async (err,decoded)=>{
            if (err) return res.status(401).json({message: 'Error al acceder'})

                const user = await User.findByPk(decoded.id)

                if(!user) return res.json({message:"Usuario no encontrado"})
                    req.user = {
            id: user.id,
            gmail: user.gmail
        }
        next()
        })
    }
    catch (error){
console.log(error)
res.status(500).json(error)
    }
}

module.exports = {isAuth}