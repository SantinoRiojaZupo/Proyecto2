const jwt = require('jsonwebtoken')
const User = require('../models/userModel.js')

const SECRET = 'EsUnSecretoooooooDeTuMiradaYLaMíaUnPresentimientoComoUnAngelQueMeDecía'

const contraseñaOlvidada = (req, res, next) => {
    try {
        // 1. Validamos que el header exista antes de hacer cualquier cosa
        const authHeader = req.headers['authorization'] || req.headers['Authorization'];
        
        if (!authHeader) {
            return res.status(401).json({ message: 'No se encontró el token de autorización en los headers' });
        }

        // 2. Extraemos el token de manera segura
        const token = authHeader.split(" ")[1] || authHeader;

        jwt.verify(token, SECRET, async (err, decoded) => {
            if (err) {
                return res.status(401).json({ message: 'Token inválido o expirado' });
            }

            const user = await User.findOne({ where: { gmail: decoded.gmail } });

            if (!user) {
                return res.status(404).json({ message: "Usuario no encontrado" });
            }

            if (user.resetPasswordToken !== token) {
                return res.status(401).json({ message: "Token de recuperación no válido" });
            }

            if (new Date() > user.resetPasswordExpires) {
                return res.status(400).json({ message: "El token ha expirado" });
            }

            req.user = {
                
                gmail: user.gmail
            };
            
            next();
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Error interno del servidor", error });
    }
}

module.exports = { contraseñaOlvidada }