const jwt = require('jsonwebtoken')
const User = require('../models/userModel.js')


const updateLastActivity = async (req, res, next) => {

    try {
        console.log("8================================D"+req.originalUrl)
        const lastActivityAt = req.originalUrl
        // console.log(req.path);
        console.log("#############################################", lastActivityAt)

        // const userId = res.user.id
        const user = await User.findByPk(req.user.id)
        // const user = await User.update({
        //     lastActivityAt: lastActivityAt
        // },
        //     { where: { id: userId } }
        // )
        user.lastActivityAt = lastActivityAt
        await user.save()
        res.json(user)


        next()

    }
    catch (error) {
        console.log(error)
        res.status(500).json(error)
    }
}

module.exports = { updateLastActivity }