const { types } = require('pg')
const sequelize = require('../config/db.js')
const DataTypes = require('sequelize')

const User = sequelize.define('User',{
    nombre :{
        type : DataTypes.STRING,
        allowNull : false,
    },
    apellido :{
        type : DataTypes.STRING,
        allowNull : false,
    },
    gmail :{
        type : DataTypes.STRING,
        allowNull: false,
        validate :{
            isEmail : true,
        }
    },
    contraseña :{
        type : DataTypes.STRING,
        allowNull: false,
    },
    resetPasswordToken:{
        type : DataTypes.STRING,
        allowNull: true,
    },
     resetPasswordExpires:{
        type : DataTypes.DATE,
        allowNull : true,
     }
},{
    timestamps : false,
    modelName: 'User'
}

)

module.exports = User