const {Router} = require('express')
const router = Router()
const {getUsers,
    usersById,
    registerUser,
    login,
    me,
    forgotPassword,
    cambiarContraseña,
    cambiarPerfil
} = require('../controllers/userController.js')
const {isAuth} = require('../middlewares/auth.js')
const {updateLastActivity} = require ('../middlewares/updateLatActivity.js')
const {contraseñaOlvidada} = require ('../middlewares/forgotPassword.js')

    router.get('/',isAuth,updateLastActivity,getUsers)
    router.get('/me',isAuth,updateLastActivity,me)
    router.post('/register',registerUser)
    router.post('/login',login)
    router.post('/forgotPassword',forgotPassword)
    router.post('/cambiarContrasena',contraseñaOlvidada,cambiarContraseña)
    router.post('/cambiarPerfil',isAuth,updateLastActivity,cambiarPerfil)
    router.get('/:id',isAuth, updateLastActivity,usersById)

    module.exports = router