const {Router} = require('express')
const router = Router()
const {getUsers,
    usersById,
    registerUser,
    login,
    me,
    forgotPassword,
    cambiarContraseña
} = require('../controllers/userController.js')
const {isAuth} = require('../middlewares/auth.js')
const {contraseñaOlvidada} = require ('../middlewares/forgotPassword.js')

    router.get('/',isAuth,getUsers)
    router.get('/me',isAuth,me)
    router.post('/register',registerUser)
    router.post('/login',login)
    router.post('/forgotPassword',forgotPassword)
    router.post('/cambiarContrasena',contraseñaOlvidada,cambiarContraseña)
    router.get('/:id',isAuth,usersById)

    module.exports = router