import { useState } from "react";
import axios from "axios"

function CambiarPerfil({setRefresh}){
const [profilePictureUrl, setprofilePictureUrl] = useState('')

    
const fetchCambiarPerfil = async ()=>{
    try{

    // 1. Buscamos el token que guardaste en el login
            const token = localStorage.getItem('token');
            console.log("token:", token)
            // 2. Hacemos el GET mandando el token en el Header 'Authorization'
            const response = await axios.post('http://localhost:3000/user/cambiarPerfil',{profilePictureUrl}, {
                headers: {
                    Authorization: `Bearer ${token}` // ¡Esta es la clave para que el backend sepa quién es!
                }
            });
            alert ("Exito ")
        }
        catch(error){
    console.log(error)
    alert(error.response.data.message)
}
}

return(
    <>
    <h2>
        Cambiar foto de Perfil
    </h2>
    
    <input type="text" placeholder="url de la foto" onChange={(event)=>setprofilePictureUrl(event.target.value)}/>
    <button variant='contained' onClick={fetchCambiarPerfil}>Cambiar </button>
    </>
)
}

export default CambiarPerfil    