import { useState } from "react";
import axios from "axios"

function GetUsers(){
    const [usuarios, setUsuarios] = useState([]);

    const fetchUsers = async ()=>{
        try {
             const token = localStorage.getItem('token');

            // 2. Hacemos el GET mandando el token en el Header 'Authorization'
            const response = await axios.get('http://localhost:3000/user/', {
                headers: {
                    Authorization: `Bearer ${token}` // ¡Esta es la clave para que el backend sepa quién es!
                }
            });

            // Guardamos los datos del usuario en el estado para mostrarlos
            setUsuarios(response.data);
        } catch (error) {
             console.error(error);
            alert(error.response?.data?.message || "No se pudo obtener la información de los usuarios");
        }
    }

    return(
        <div>

        <h2>Sobre Mí</h2>
            <button onClick={fetchUsers}>cargarUsuarios</button>
            {usuarios.map(usuario=>(
                
                <div>
            <p><strong>Nombre:</strong> {usuario.nombre}</p>
                    <p><strong>Apellido:</strong> {usuario.apellido}</p>
                    <p><strong>Email:</strong> {usuario.gmail}</p>

                    </div>
            ))}
        </div>
    )
}


export default GetUsers