import { useState } from "react";
import axios from "axios"

function Login({setRefresh}){
const [gmail, setGmail] = useState('')
const [contraseña,setContraseña] = useState('')
    
const fetchLogin = async ()=>{
    try{

    const response =await axios.post('http://localhost:3000/user/login',{
        gmail,
        contraseña
    })
    alert("Login exitoso")
    localStorage.setItem('token',response.data.token)
    setRefresh("Login")
}
catch(error){
    alert(error.response.data.message)
}
}

return(
    <>
    <h2>
        Login
    </h2>
    <input type="text" placeholder="gmail" onChange={(event)=>setGmail(event.target.value)} />
    <input type="text" placeholder="contraseña" onChange={(event)=>setContraseña(event.target.value)}/>
    <button variant='contained' onClick={fetchLogin}>Login </button>
    </>
)
}

export default Login    