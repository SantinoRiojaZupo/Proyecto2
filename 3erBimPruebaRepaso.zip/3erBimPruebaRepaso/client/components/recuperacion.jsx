import { useState } from "react";
import axios from "axios"

function Recuperar({ setRefresh }) {
    const [gmail, setGmail] = useState('')
    const [contraseña, setContraseña] = useState('')

    const fetchRecuperar = async () => {
        try {

            const response = await axios.post('http://localhost:3000/user/forgotPassword', {
                gmail,
                contraseña
            })
            alert("exitoso")
            localStorage.setItem('tokenRecuperar', response.data.tokenRecuperacion)

        }
        catch (error) {
            alert(error.response.data.message)
        }
    }
    const fetchCambiar = async () => {
        try {
            const token = localStorage.getItem('tokenRecuperar');
            console.log("Token enviado al cambiar:", token);

            const response = await axios.post('http://localhost:3000/user/cambiarContrasena', {
                contraseña // Solo mandamos la nueva contraseña
            }, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });

            alert("¡Contraseña cambiada con éxito!");
        }
        catch (error) {
            alert(error.response?.data?.message || "Error al cambiar");
        }
    }
    return (
        <>
            <h2>
                Recuperar contraseña
                <button variant='contained' onClick={fetchRecuperar}>Olvide mi contraseña </button>
            </h2>
            <input type="text" placeholder="gmail" onChange={(event) => setGmail(event.target.value)} />
            <input type="text" placeholder="contraseña" onChange={(event) => setContraseña(event.target.value)} />
            <button variant='contained' onClick={fetchCambiar}>cambiar </button>
        </>
    )
}

export default Recuperar   