import { useState } from "react";
import axios from "axios";

function Register({setRefresh}){

const [nombre,setNombre]= useState("")
const [apellido,setApellido]= useState("")
const [gmail,setGmail]= useState("")
const [contraseña,setContraseña]= useState("")


const fetchRegister = async (e)=>{
e.preventDefault(); // <--- Esto evita que la página se recargue sola
    try{
    const response = await axios.post('http://localhost:3000/user/register',{
        nombre,apellido,gmail,contraseña
    })
    if (response.status== (200)){
        alert("Usuario Creado")

    }
}
catch(error){
    console.log(error)
   alert(error.response?.data?.message || "Error al registrar usuario");
}
}



return(
<>
<h2>Register</h2>
<input type="text" placeholder="nombre" onChange={(event)=>setNombre(event.target.value)} />
<input type="text" placeholder="apellido" onChange={(event)=>setApellido(event.target.value)} />
<input type="text" placeholder="gmail" onChange={(event)=>setGmail(event.target.value)} />
<input type="text" placeholder="contraseña" onChange={(event)=>setContraseña(event.target.value)} />
<button onClick={fetchRegister}>Registrar</button>
</>
)
    
}
export default Register