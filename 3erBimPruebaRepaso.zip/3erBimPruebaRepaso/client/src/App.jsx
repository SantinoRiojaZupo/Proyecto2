import { useState } from 'react'
import Login from '../components/login'
import Register from '../components/register'
import SobreMi from '../components/sobreMi'
import GetUsers from '../components/getUsers'
import GetUser from '../components/userId'
import Recuperar from '../components/recuperacion'
import { Link, Route,Routes, useNavigate } from 'react-router-dom'
import './App.css'

function App() {
 const navigate = useNavigate();
  const [refresh, setRefresh] = useState("")
  console.log(refresh);
  
  const logout = () => {
    localStorage.removeItem('token');
    alert('sesion cerrada')
    navigate('/login');
    setRefresh("logout")
  };

     return (
    <div>
      {/* Navbar Superior */}
      <header>
        <div>UserApp</div>
        <nav>
          <Link to="/login">Iniciar Sesión</Link>
          <Link to="/register">Registrarse</Link>
          <Link to="/sobremi">Sobre Mí</Link> 
          <Link to="/getUsers">cargar lista usarios</Link> 
          <Link to="/getUser">cargar usario</Link> 
          <Link to="/recuperar">cargar usario</Link> 
          
          <button onClick={logout}>Cerrar Sesión</button>
        </nav>
      </header>

      {/* Contenido Principal */}
      <main>
        {/* Sección de Rutas Dinámicas */}
        <section>
          <Routes>
            <Route element={<Login setRefresh={setRefresh} />} path="/login" />
            <Route element={<Register setRefresh={setRefresh} />} path="/register" />
            <Route element={<SobreMi setRefresh={setRefresh}/>} path="/sobremi" /> 
            <Route element={<GetUsers setRefresh={setRefresh}/>} path="/getUsers" />
            <Route element={<GetUser setRefresh={setRefresh}/>} path="/getUser" />
            <Route element={<Recuperar setRefresh={setRefresh}/>} path="/recuperar" />
          </Routes>
        </section>
      </main>
    </div>
  );
}

export default App
