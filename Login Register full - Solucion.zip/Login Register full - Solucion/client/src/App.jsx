import { Link, Route, Routes, useNavigate } from 'react-router-dom';
import Buscar from './components/Buscarusuario';
import Login from './components/Login';
import Register from './components/Register';
import UserList from './components/UserList';
import { useState } from 'react';

function App() {
  const navigate = useNavigate();
  const [refresh, setRefresh] = useState("")
  console.log(refresh);
  
  const logout = () => {
    localStorage.removeItem('token');
    alert('sesion cerrada')
    navigate('/login');
    setRefresh("logout")
  };

  return (
    <div style={styles.appContainer}>
      {/* Navbar Superior */}
      <header style={styles.header}>
        <div style={styles.logo}>UserApp</div>
        <nav style={styles.nav}>
          <Link to="/login" style={styles.navLink}>
            Iniciar Sesión
          </Link>
          <Link to="/register" style={{ ...styles.navLink, ...styles.navLinkPrimary }}>
            Registrarse
          </Link>
          <button style={styles.logoutBtn} onClick={logout}>
            Cerrar Sesión
          </button>
        </nav>
      </header>

      {/* Contenido Principal */}
      <main style={styles.mainContent}>
        {/* Panel lateral / Herramientas de Usuarios */}
        <section style={styles.dashboardSection}>
          <Buscar />
          <UserList refresh={refresh}/>
        </section>

        {/* Sección de Rutas Dinámicas */}
        <section style={styles.routesSection}>
          <Routes>
            <Route element={<Login setRefresh={setRefresh} />} path="/login" />
            <Route element={<Register />} path="/register" />
          </Routes>
        </section>
      </main>
    </div>
  );
}

const styles = {
  appContainer: {
    minHeight: '100vh',
    backgroundColor: '#090d16',
    fontFamily: 'Inter, system-ui, -apple-system, sans-serif',
    color: '#f1f5f9',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '1rem 2rem',
    backgroundColor: '#0f172a',
    borderBottom: '1px solid #1e293b',
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.3)',
  },
  logo: {
    fontSize: '1.25rem',
    fontWeight: '700',
    color: '#f8fafc',
    letterSpacing: '-0.025em',
  },
  nav: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
  },
  navLink: {
    textDecoration: 'none',
    color: '#94a3b8',
    fontWeight: '500',
    fontSize: '0.9rem',
    padding: '0.5rem 0.85rem',
    borderRadius: '6px',
    transition: 'all 0.2s',
  },
  navLinkPrimary: {
    backgroundColor: '#2563eb',
    color: '#ffffff',
  },
  logoutBtn: {
    backgroundColor: '#dc2626',
    color: '#ffffff',
    border: 'none',
    padding: '0.5rem 0.85rem',
    borderRadius: '6px',
    fontWeight: '500',
    fontSize: '0.9rem',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
  },
  mainContent: {
    maxWidth: '1200px',
    margin: '2rem auto',
    padding: '0 1.5rem',
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '2rem',
  },
  dashboardSection: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1.5rem',
    backgroundColor: '#0f172a',
    padding: '1.5rem',
    borderRadius: '12px',
    border: '1px solid #1e293b',
  },
  routesSection: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start',
  },
};

export default App;