import { useState } from 'react';
import axios from 'axios';

function Buscar() {
    const [id, setId] = useState('');
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const fetchbuscar = async (e) => {
        if (e) e.preventDefault();
        if (!id.trim()) return;

        setLoading(true);
        setError('');
        setUser(null);

        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`http://localhost:3000/users/${id}`, {
                headers: {
                    authorization: token
                }
            });

            if (response.status === 200) {
                setUser(response.data);
            }
        } catch (err) {
            setError(err.response?.data?.message || 'No se encontró el usuario o token inválido.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={styles.card}>
            <h2 style={styles.title}>Buscar Usuario</h2>

            <form onSubmit={fetchbuscar} style={styles.searchBox}>
                <input
                    type="text"
                    placeholder="Ingrese ID del usuario"
                    value={id}
                    onChange={(event) => setId(event.target.value)}
                    style={styles.input}
                />
                <button 
                    type="submit" 
                    disabled={loading || !id.trim()}
                    style={{
                        ...styles.button,
                        opacity: loading || !id.trim() ? 0.6 : 1,
                        cursor: loading || !id.trim() ? 'not-allowed' : 'pointer'
                    }}
                >
                    {loading ? 'Buscando...' : 'Buscar'}
                </button>
            </form>

            {/* Mensaje de Error */}
            {error && <div style={styles.errorAlert}>{error}</div>}

            {/* Resultado del usuario */}
            {user ? (
                <div style={styles.userCard}>
                    <div style={styles.avatar}>
                        {user.firstName?.[0]?.toUpperCase() || 'U'}
                    </div>
                    <div style={styles.userInfo}>
                        <h3 style={styles.userName}>{user.firstName} {user.lastName}</h3>
                        {user.email && <p style={styles.userEmail}>{user.email}</p>}
                        <span style={styles.userId}>ID: {user._id || user.id || id}</span>
                    </div>
                </div>
            ) : (
                !loading && !error && (
                    <p style={styles.placeholderText}>Ingresa un ID arriba para ver la información del usuario.</p>
                )
            )}
        </div>
    );
}

const styles = {
    card: {
        backgroundColor: '#ffffff',
        padding: '1.5rem',
        borderRadius: '12px',
        border: '1px solid #e2e8f0',
        display: 'flex',
        flexDirection: 'column',
        gap: '1rem',
    },
    title: {
        margin: 0,
        fontSize: '1.25rem',
        fontWeight: '600',
        color: '#0f172a'
    },
    searchBox: {
        display: 'flex',
        gap: '0.5rem'
    },
    input: {
        flex: 1,
        padding: '0.65rem 0.9rem',
        borderRadius: '6px',
        border: '1px solid #cbd5e0',
        fontSize: '0.9rem',
        outline: 'none',
    },
    button: {
        padding: '0.65rem 1.2rem',
        backgroundColor: '#2563eb',
        color: '#ffffff',
        border: 'none',
        borderRadius: '6px',
        fontSize: '0.9rem',
        fontWeight: '500',
        transition: 'background-color 0.2s',
    },
    errorAlert: {
        padding: '0.75rem',
        backgroundColor: '#fef2f2',
        color: '#991b1b',
        borderRadius: '6px',
        fontSize: '0.85rem',
        border: '1px solid #fecaca'
    },
    userCard: {
        display: 'flex',
        alignItems: 'center',
        gap: '1rem',
        padding: '1rem',
        backgroundColor: '#f8fafc',
        borderRadius: '8px',
        border: '1px solid #f1f5f9',
        marginTop: '0.5rem'
    },
    avatar: {
        width: '42px',
        height: '42px',
        borderRadius: '50%',
        backgroundColor: '#3b82f6',
        color: '#ffffff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontWeight: '600',
        fontSize: '1.1rem'
    },
    userInfo: {
        display: 'flex',
        flexDirection: 'column',
        gap: '0.2rem'
    },
    userName: {
        margin: 0,
        fontSize: '1rem',
        fontWeight: '600',
        color: '#1e293b'
    },
    userEmail: {
        margin: 0,
        fontSize: '0.85rem',
        color: '#64748b'
    },
    userId: {
        fontSize: '0.75rem',
        color: '#94a3b8',
        fontWeight: '500'
    },
    placeholderText: {
        margin: 0,
        fontSize: '0.875rem',
        color: '#94a3b8',
        textAlign: 'center',
        padding: '1rem 0'
    }
};

export default Buscar;