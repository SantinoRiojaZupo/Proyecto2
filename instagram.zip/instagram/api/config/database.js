const { Sequelize } = require('sequelize');

// Configura con tus datos de PostgreSQL (nombre de bd, usuario, contraseña)
const sequelize = new Sequelize('instagram_db', 'postgres', '1234', {
    host: 'localhost',
    dialect: 'postgres',
    logging: false // Evita que llene la consola con logs SQL
});

module.exports = sequelize;