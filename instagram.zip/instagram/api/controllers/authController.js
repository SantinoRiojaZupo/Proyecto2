const { usuarios } = require('../models');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const JWT_SECRET = 'clave_secreta_super_segura'; 

// --- REGISTER ---
const register = async (req, res) => {
    try {
        const { username, email, password } = req.body;

        // 1. Encriptar la contraseña con bcrypt
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // 2. Crear el usuario en la base de datos
        const newUser = await usuarios.create({
            username,
            email,
            password: hashedPassword
        });

        res.status(201).json({ message: "Usuario registrado con éxito", user: { id: newUser.id, username: newUser.username } });
    } catch (error) {
        res.status(500).json({ error: "Error al registrar usuario", details: error.message });
    }
};

// --- LOGIN ---
const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // 1. Buscar usuario por email
        const user = await usuarios.findOne({ where: { email } });
        if (!user) {
            return res.status(404).json({ message: "Usuario no encontrado" });
        }

        // 2. Comparar la contraseña ingresada con la encriptada usando bcrypt
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({ message: "Contraseña incorrecta" });
        }

        // 3. Generar token JWT
        const token = jwt.sign(
            { id: user.id, username: user.username },
            JWT_SECRET,
            { expiresIn: '2h' }
        );

        res.status(200).json({
            message: "Login exitoso",
            token,
            user: { id: user.id, username: user.username, email: user.email }
        });
    } catch (error) {
        res.status(500).json({ error: "Error en el servidor", details: error.message });
    }
};

module.exports = {
    register,
    login
};