const { posts, usuarios , likes} = require('../models');

// --- CREAR POST (Funcionalidad 1) ---
const createPost = async (req, res) => {
    try {
        const { image, caption, id_usuario } = req.body;

        const newPost = await posts.create({
            image,
            caption,
            id_usuario
        });

        res.status(201).json({ message: "Publicación creada con éxito", post: newPost });
    } catch (error) {
        res.status(500).json({ error: "Error al crear la publicación", details: error.message });
    }
};

// --- OBTENER TODOS LOS POSTS / FEED (Funcionalidad 2) ---
const getFeed = async (req, res) => {
    try {
        const allPosts = await posts.findAll({
            include: [
                {
                    model: usuarios,
                    attributes: ['id', 'username']
                },
                {
                    model: likes // <--- Asegúrate de incluir los likes aquí
                }
            ],
            order: [['createdAt', 'DESC']]
        });
        res.status(200).json(allPosts);
    } catch (error) {
        res.status(500).json({ error: "Error al obtener el feed", details: error.message });
    }
};
// --- DAR O QUITAR LIKE A UN POST (Funcionalidad 3) ---
const toggleLike = async (req, res) => {
    try {
        const { postId } = req.params;
        const { id_usuario } = req.body; // O sacado del token JWT si lo implementas luego

        const post = await posts.findByPk(postId);
        if (!post) {
            return res.status(404).json({ message: "Publicación no encontrada" });
        }

        // Verificamos si el usuario ya le dio like usando el modelo de la tabla intermedia
        const existingLike = await likes.findOne({
            where: { id_post: postId, id_usuario: id_usuario }
        });

        if (existingLike) {
            // Si ya existía, se lo quitamos (Dislike / unlike)
            await existingLike.destroy();
            return res.status(200).json({ message: "Like removido con éxito" });
        } else {
            // Si no existe, se lo agregamos
            await likes.create({ id_post: postId, id_usuario: id_usuario });
            return res.status(200).json({ message: "Like agregado con éxito" });
        }
    } catch (error) {
        res.status(500).json({ error: "Error al procesar el like", details: error.message });
    }
};

module.exports = {
    createPost,
    getFeed,
    toggleLike
};