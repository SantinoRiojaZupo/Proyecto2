const express = require('express');
const cors = require('cors');
const sequelize = require('./config/database.js');

// 1. Importamos los modelos para que Sequelize registre las tablas y relaciones
const { usuarios, posts, likes } = require('./models');

// 2. Importamos las rutas
const authRoutes = require('./routes/authRoutes');
const postRoutes = require('./routes/postRoutes');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// 3. Montamos las rutas
app.use('/auth', authRoutes); // Ej: /auth/register y /auth/login
app.use('/posts', postRoutes); // Ej: /posts para crear, listar y dar like

const PORT = 3000;

// 4. Sincronización con PostgreSQL y arranque del servidor
sequelize.sync({ force: false }) // force: false no borra los datos al reiniciar el servidor
  .then(() => {
    console.log(' Conexión a la base de datos PostgreSQL establecida con éxito.');
    console.log(' Tablas sincronizadas correctamente.');
    app.listen(PORT, () => {
      console.log(` Servidor backend corriendo en http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error(' Error al conectar con la base de datos PostgreSQL:', error);
  });