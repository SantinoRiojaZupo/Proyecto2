const { usuarios } = require('./usuariosModel.js');
const { posts } = require('./postModel.js');
const { likes } = require('./likesModel.js');

// Relación de Usuario con Posts (Uno a Muchos)
usuarios.hasMany(posts, {
    foreignKey: 'id_usuario',
    onDelete: 'CASCADE'
});
posts.belongsTo(usuarios, {
    foreignKey: 'id_usuario'
});

// Relación de Likes (Muchos a Muchos: un usuario da like a muchos posts, un post tiene muchos likes)
usuarios.belongsToMany(posts, {
    through: likes,
    foreignKey: 'id_usuario',
    otherKey: 'id_post'
});
posts.belongsToMany(usuarios, {
    through: likes,
    foreignKey: 'id_post',
    otherKey: 'id_usuario'
});
posts.hasMany(likes, { foreignKey: 'id_post' });
likes.belongsTo(posts, { foreignKey: 'id_post' });

module.exports = {
    usuarios,
    posts,
    likes
};