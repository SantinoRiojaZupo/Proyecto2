const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const likes = sequelize.define('likes', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    }
}, {
    tableName: 'likes',
    timestamps: true
});

module.exports = { likes };