const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const posts = sequelize.define('posts', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    image: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    caption: {
        type: DataTypes.STRING,
        allowNull: true
    },
    id_usuario: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    tableName: 'posts',
    timestamps: true
});

module.exports = { posts };