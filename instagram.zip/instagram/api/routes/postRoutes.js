const { Router } = require("express");
const { createPost, getFeed, toggleLike } = require("../controllers/postController");

const router = Router();

router.post('/', createPost);           // Funcionalidad 1: Crear post
router.get('/', getFeed);               // Funcionalidad 2: Ver el feed de publicaciones
router.post('/:postId/like', toggleLike); // Funcionalidad 3: Dar o quitar like a un post

module.exports = router;