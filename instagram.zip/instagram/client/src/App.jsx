import { Routes, Route } from "react-router-dom"
import Header from "./components/Header"
import Login from "./pages/Login"
import Register from "./pages/Register"
import Feed from "./pages/Feed"
import CreatePost from "./pages/CreatePost"
import './App.css';

function App() {
  return (
    <>
      <Header />
      <Routes>
        {/* Ruta principal: Pantalla de Login */}
        <Route path="/" element={<Login />} />
        
        {/* Ruta para el Registro */}
        <Route path="/register" element={<Register />} />
        
        {/* Ruta para el Feed principal (Ver publicaciones y dar likes) */}
        <Route path="/feed" element={<Feed />} />
        
        {/* Ruta para Crear una nueva publicación */}
        <Route path="/create" element={<CreatePost />} />
      </Routes>
    </>
  )
}

export default App