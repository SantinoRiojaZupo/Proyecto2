export default function Header() {
  return (
    <header>
      <h3>Instagram</h3>
    </header>
  );
}