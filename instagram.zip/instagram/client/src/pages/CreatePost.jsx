import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function CreatePost() {
  const [image, setImage] = useState("");
  const [caption, setCaption] = useState("");
  const navigate = useNavigate();
  
  const user = JSON.parse(localStorage.getItem("user"));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) {
      alert("Debes iniciar sesión");
      navigate("/");
      return;
    }

    try {
      await axios.post("http://localhost:3000/posts", {
        image,
        caption,
        id_usuario: user.id
      });
      alert("¡Publicación creada con éxito!");
      navigate("/feed");
    } catch (error) {
      console.error("Error al crear post:", error);
      alert("Error al crear la publicación");
    }
  };

  return (
    <div className="container">
      <div className="auth-card" style={{ maxWidth: "450px" }}>
        <h2 style={{ fontSize: "24px", fontWeight: "600", marginBottom: "20px" }}>Crear nueva publicación</h2>
        <form onSubmit={handleSubmit} className="auth-form">
          <input 
            type="text" 
            placeholder="URL de la imagen (ej: https://...)" 
            value={image} 
            onChange={(e) => setImage(e.target.value)} 
            required 
            className="auth-input"
          />
          <textarea 
            placeholder="Escribe una descripción..." 
            value={caption} 
            onChange={(e) => setCaption(e.target.value)} 
            rows="3"
            className="auth-input"
            style={{ resize: "none", fontFamily: "inherit" }}
          />
          <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
            <button type="submit" className="ig-button" style={{ flex: 1 }}>
              Compartir
            </button>
            <button type="button" onClick={() => navigate("/feed")} className="ig-button ig-button-danger" style={{ flex: 1 }}>
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}