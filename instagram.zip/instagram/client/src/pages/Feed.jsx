import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Feed() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  
  const user = JSON.parse(localStorage.getItem("user"));

  const fetchFeed = async () => {
    try {
      const response = await axios.get("http://localhost:3000/posts");
      setPosts(response.data);
      setLoading(false);
    } catch (error) {
      console.error("Error al cargar el feed:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFeed();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/");
  };

  const handleLike = async (postId) => {
    if (!user) {
      alert("Debes iniciar sesión para dar like");
      return;
    }
    try {
      await axios.post(`http://localhost:3000/posts/${postId}/like`, {
        id_usuario: user.id
      });
      fetchFeed();
    } catch (error) {
      console.error("Error al dar like:", error);
    }
  };

  if (loading) return <p style={{ textAlign: "center" }}>Cargando publicaciones...</p>;

  return (
    <div>
      {/* Barra superior fija tipo Instagram */}
      <div className="feed-header">
        <h2>Instagram</h2>
        <div style={{ display: "flex", gap: "10px" }}>
          <button onClick={() => navigate("/create")} className="ig-button">
            Crear Publicación
          </button>
          <button onClick={handleLogout} className="ig-button ig-button-danger">
            Cerrar Sesión
          </button>
        </div>
      </div>

      {/* Contenedor central del feed */}
      <div className="container">
        {posts.length === 0 ? (
          <p style={{ textAlign: "center" }}>No hay publicaciones todavía.</p>
        ) : (
          posts.map((post) => {
            const yaDioLike = post.likes && post.likes.some(l => l.id_usuario === user.id);

            return (
              <div key={post.id} className="post-card">
                {/* Cabecera del post (Usuario) */}
                <div className="post-header">
                  <span>@{post.usuario ? post.usuario.username : "Usuario"}</span>
                </div>
                
                {/* Imagen del post */}
                <img src={post.image} alt="Post" className="post-image" />
                
                {/* Pie del post (Botón like y descripción) */}
                <div className="post-footer">
                  <div className="post-actions">
                    <button onClick={() => handleLike(post.id)} className="like-btn">
                      {yaDioLike ? "❤️" : "🤍"}
                    </button>
                    <span style={{ fontWeight: "600", fontSize: "14px" }}>
                      {post.likes ? post.likes.length : 0} Me gusta
                    </span>
                  </div>
                  
                  <p className="post-caption">
                    <strong>@{post.usuario ? post.usuario.username : "Usuario"}</strong> {post.caption}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}