import { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:3000/auth/login", {
        email,
        password,
      });
      localStorage.setItem("token", response.data.token);
      localStorage.setItem("user", JSON.stringify(response.data.user));
      navigate("/feed");
    } catch (error) {
      alert("Error al iniciar sesión: " + (error.response?.data?.message || error.message));
    }
  };

  return (
    <div className="auth-card">
      <h2 style={{ background: "linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
        Instagram
      </h2>
      <form onSubmit={handleLogin} className="auth-form">
        <input 
          type="email" 
          placeholder="Correo electrónico" 
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
          required 
          className="auth-input"
        />
        <input 
          type="password" 
          placeholder="Contraseña" 
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
          required 
          className="auth-input"
        />
        <button type="submit" className="ig-button">
          Ingresar
        </button>
      </form>
      <p style={{ marginTop: "20px", fontSize: "14px", color: "#737373" }}>
        ¿No tienes cuenta? <Link to="/register" style={{ color: "#0095f6", textDecoration: "none", fontWeight: "600" }}>Regístrate aquí</Link>
      </p>
    </div>
  );
}