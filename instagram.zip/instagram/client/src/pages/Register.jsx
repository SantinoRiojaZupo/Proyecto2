import { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";

export default function Register() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:3000/auth/register", {
        username,
        email,
        password,
      });
      alert("¡Cuenta creada con éxito! Ahora inicia sesión.");
      navigate("/");
    } catch (error) {
      alert("Error en el registro: " + (error.response?.data?.error || error.message));
    }
  };

  return (
    <div className="auth-card">
      <h2 style={{ background: "linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
        Registrarse
      </h2>
      <form onSubmit={handleRegister} className="auth-form">
        <input 
          type="text" 
          placeholder="Nombre de usuario" 
          value={username} 
          onChange={(e) => setUsername(e.target.value)} 
          required 
          className="auth-input"
        />
        <input 
          type="email" 
          placeholder="Correo electrónico" 
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
          required 
          className="auth-input"
        />
        <input 
          type="password" 
          placeholder="Contraseña" 
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
          required 
          className="auth-input"
        />
        <button type="submit" className="ig-button">
          Registrarse
        </button>
      </form>
      <p style={{ marginTop: "20px", fontSize: "14px", color: "#737373" }}>
        ¿Ya tienes cuenta? <Link to="/" style={{ color: "#0095f6", textDecoration: "none", fontWeight: "600" }}>Inicia sesión aquí</Link>
      </p>
    </div>
  );
}